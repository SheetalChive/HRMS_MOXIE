<?php
session_start();
if(!isset($_SESSION["id"])){
	echo "<script>window.location.href='index.php';</script>";
}
$loginid=$_SESSION["id"];
$username=$_SESSION['name'];
include '../config.php';
$query=mysqli_query($conn,"select * from employee where username='$username' ") or die (mysqli_error($conn));
$result=mysqli_fetch_array($query);

// $from = $result['from_date'];
$id=$result['emp_id'];
// $dept=$result['department'];

// $name=$result['name'];

// $from = $result['from_date'];
// $to = $result['to_date'];

// $desc =$result['description'];


?>

       
<?php



if(isset($_POST['submit'])){
    // $id=$_POST['id'];
    $emp_id=$_POST['emp_id'];
    $name=$_POST['name'];
    $admin_action=$_POST['admin_action'];
    $from_date=$_POST['from_date'];
    $to_date=$_POST['to_date'];
    $approval=$_POST['approval'];


   

   
   $result=mysqli_query($conn, "update apply_leave1 set admin_action='$admin_action',approval='$approval',extended_date_from='$from_date',extended_date_to='$to_date' where id='" . $_GET['ids'] . "'");

    echo "<script> window.location = 'Pending_Leave_History.php' </script>";
}


?>


<?php
include 'config.php';


// $id = $_GET['emp_id'];
$query=mysqli_query($conn,"select * from apply_leave1 where id='" . $_GET['ids'] . "'");
$result=mysqli_fetch_array($query);
$id=$result['emp_id'];
$dept=$result['department'];

$name=$result['name'];

$from = $result['from_date'];
$to = $result['to_date'];
$desc =$result['description'];
$admin_action = $result['admin_action'];
$approval=$result['approval'];
$from_date=$result['from_date'];
$to_date=$result['to_date'];
$leave_type = $result['leave_type'];

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>MOXIEDECK HRMS</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="../plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="../plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="../plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- JQuery DataTable Css -->
    <link href="../plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Custom Css -->
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/custom.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="../css/themes/all-themes.css" rel="stylesheet" />
</head>

<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
   <?php
    include './header.php' 
    ?>

    <section class="content">
        <div class="container-fluid">
           
            <!-- Exportable Table -->
           <!-- Striped Rows -->
           <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                               Leave Details
                                <!-- <small>Use <code>.table-striped</code> to add zebra-striping to any table row within the <code>&lt;tbody&gt;</code></small> -->
                            </h2>
                            
                            
                        </div>


                        <div class="body">
                            <form id="form_validation" method="POST">


                            <div class="row clearfix">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="apply_date" name = "order_date " value="<?php echo date("Y-d-m"); ?>" readonly>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="emp_id" value ="<?php echo "$id" ?>" readonly>
                                        <label class="form-label">Employeen ID</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row clearfix">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="name" value = "<?php echo "$name" ?>" readonly>
                                        <label class="form-label">Employee Name</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="emp_id" value ="<?php echo "$dept" ?>" readonly>
                                        <label class="form-label">Department</label>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row clearfix">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="leave_type" value = "<?php echo "$leave_type" ?>" readonly>
                                        <label class="form-label"> Leave Type</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="from" value = "<?php echo "$desc" ?>" readonly>
                                        <label class="form-label">Description from Employee</label>
                                        </div>
                                    </div>
                                </div>
                            </div>


                
                       

                            

                            <div class="row clearfix">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="from" value = "<?php echo  "   FROM  ", "$from" , "   TO  "," $to"  ?>" readonly>
                                        <label class="form-label">Date Requested</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                         

                            <div class="row clearfix">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="admin_action" value = "<?php echo "$admin_action" ?>"   required>
                                        <label class="form-label">Admin Action</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <h5>Leave Date Extended:</h5><br>
                            <div class="row clearfix">
                                <div class="col-md-3">
                                    <b>From</b>
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <!-- <i class="material-icons">date_range</i> -->
                                        </span>
                                        <div class="form-line">
                                            <input type="date" class="form-control date" name="from_date"  value = "<?php echo "$from_date" ?>"   >
                                        </div>
                                    </div>
                                    
                                    </div>

                                    

                                    <div class="col-md-3">
                                        <b>TO</b>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <!-- <i class="material-icons">date_range</i> -->
                                            </span>
                                            <div class="form-line">
                                                <input type="date" class="form-control time24" name="to_date" value = "<?php echo "$to_date" ?>"   >
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="row clearfix">
                                    <div class="col-md-6">
                                        <div class="input-group">
                                            <h5 >Manager / Superviser</h5>
                                            <div class="demo-radio-button">
                                                <input name="approval" type="radio" id="radio_1" value="Approved" <?php echo ($approval=='Approved')?"checked":"" ;?> readonly/>
                                                <label for="radio_1">Approved</label>
                                                <input name="approval" type="radio" id="radio_2" value="Reject" <?php echo ($approval=='Reject')?"checked":"" ;?>/>
                                                <label for="radio_2">Reject</label>
                                   
                                            </div>
                                        </div>
                                    </div>
                                </div>

                           
   
<?php
  if($approval=='Approved')
  {
     
  }
  elseif($approval=='Reject')
  {
     
  }
  else
  {
    echo' <center><button type="submit" name="submit" class="btn btn-primary waves-effect">SUBMIT</button></center>';
  }
?>   
                             
                                <!-- 
                                    <center><button class="btn btn-primary waves-effect" type="submit" name="submit">SUBMIT</button></center> -->
                            </div>


                               
                            
                                

                                    
                                  <br>
                           
                            </form>   
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Striped Rows -->
        </div>
    </section>
    

  





        <!-- edit employee Modal -->
        


    <!-- Jquery Core Js -->
    <script src="../plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="../plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="../plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="../plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="../plugins/node-waves/waves.js"></script>
    <script src="../plugins/jquery-validation/jquery.validate.js"></script>
    <script src="../js/pages/forms/form-validation.js"></script>
    <!-- Jquery DataTable Plugin Js -->
    <script src="../plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="../plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

    <!-- Custom Js -->
    <script src="../js/admin.js"></script>
    <script src="../js/pages/tables/jquery-datatable.js"></script>

    <!-- Demo Js -->
    <script src="../js/demo.js"></script>
    
</body>

</html>
