<?php

include '../config.php';



$id=$_GET['id'];
$query=mysqli_query($conn, "delete from employee where emp_id='$id'") or die(mysqli_error($conn));
echo "<script> window.location = 'view_employee.php' </script>";


