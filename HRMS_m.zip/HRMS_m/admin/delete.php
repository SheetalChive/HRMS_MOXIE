<?php

include '../config.php';



// $ids=$_GET['emp_id'];
$query=mysqli_query($conn, "delete from apply_leave1 where id='" . $_GET['ids'] . "'") or die(mysqli_error($conn));
echo "<script> window.location = 'Pending_Leave_History.php' </script>";

// $id=$_GET['id'];
// $query=mysqli_query($conn, "delete from employee where emp_id='$id'") or die(mysqli_error($conn));
// echo "<script> window.location = 'view_employee.php' </script>";


