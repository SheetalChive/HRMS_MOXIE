<?php 

$conn=mysqli_connect('localhost','root','','hrms') or die(mysqli_error($conn));
