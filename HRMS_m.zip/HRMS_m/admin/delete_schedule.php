<?php

include '../config.php';



// $idss=$_GET['emp_id'];
// $query=mysqli_query($conn, "delete from emp_schedule where id='" . $_GET['idss'] . "'") or die(mysqli_error($conn));
// echo "<script> window.location = 'delete_schedule.php' </script>";

$id=$_GET['id'];
$query=mysqli_query($conn, "delete from emp_schedule where id='" . $_GET['id'] . "'") or die(mysqli_error($conn));
echo "<script> window.location = 'schedule.php' </script>";

