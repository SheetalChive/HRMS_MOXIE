<?php
session_start();
if(!isset($_SESSION["id"])){
	echo "<script>window.location.href='index.php';</script>";
}
$username=$_SESSION['name'];



?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>MOXIEDECK HRMS</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="../plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="../plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="../plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- JQuery DataTable Css -->
    <link href="../plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Custom Css -->
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/custom.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="../css/themes/all-themes.css" rel="stylesheet" />

    
</head>

</body>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
   <?php include './header.php' ?>

    <section class="content">
        <div class="container-fluid">
           
            <!-- Exportable Table -->
           <!-- Striped Rows -->
           <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                               Employee List
                                <!-- <small>Use <code>.table-striped</code> to add zebra-striping to any table row within the <code>&lt;tbody&gt;</code></small> -->
                            </h2>
                             
                            <div class="header-dropdown m-r--5">
                            <a class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus" style="color:white" aria-hidden="true"></i>&nbsp;Add Employee</a>
                        </div>
                    </div>
                    
                        <div class="body table-responsive">
                        
                            <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>NAME</th>
                                        <th>EMAIL</th>
                                        <th>CONTACT</th>
                                        <th>USERNAME</th>
                                        <th>PASSWORD</th>
                                        <th colspan="2">ACTION</th>
                                    </tr>
                                </thead>
                                <tbody id="myTable">
                                    <?php include '../config.php';
                                    $query = mysqli_query($conn,"select * from employee ");
                                    $count = 1;
                                    while($row =mysqli_fetch_array($query)){
                                        $id= $row['emp_id'];
                                    ?>

                                    <tr>
                                        <th scope="row"><?php echo $count ?></th>
                                        <td><?php echo $row['name']; ?></td>
                                        <td><?php echo $row['email']; ?></td>
                                        <td><?php echo $row['contact']; ?></td>
                                        <td><?php echo $row['username']; ?></td>
                                        <td><?php echo $row['password']; ?></td>
                                        <td><a href="delete.php?id=<?php echo $row['emp_id']; ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash-o" data-toggle="tooltip" title="Delete" style="color:red;" aria-hidden="true"></i></td>
                                        <!-- <td><a href="#myModal" id="custId" data-toggle="modal" data-id="<? echo $row['emp_id']; ?>"><i class="fa fa-pencil-square-o"  data-toggle="tooltip" title="Edit" style="color:green;" aria-hidden="true"></i></td> -->
                                        <td><a href="emp_edit.php?emp_id=<?php echo $row['emp_id']; ?>" ><i class="fa fa-pencil-square-o"  data-toggle="tooltip" title="Edit" style="color:green;" aria-hidden="true"></i></a></td>
                                    </tr>
                                <?php 

                                $count ++;
                                    }
                                    ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Striped Rows -->
        </div>
    </section>
    

            <!-- Add employee Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <!-- <h5 class="modal-title" id="exampleModalLabel">Modal title</h5> -->
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row clearfix">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="card">
                                <div class="header">
                                    <h2>Employee Registration</h2>
                                    
                                </div>
                                <div class="body">
                                    <form id="form_validation" method="POST">
                                        <div class="form-group form-float">
                                            <div class="form-line">
                                                <input type="text" class="form-control" name="name" required>
                                                <label class="form-label">Employee Name</label>
                                            </div>
                                        </div>
                                        <div class="form-group form-float">
                                            <div class="form-line">
                                                <input type="email" class="form-control" name="email" required>
                                                <label class="form-label">Email</label>
                                            </div>
                                        </div>
                                        <div class="form-group form-float">
                                            <div class="form-line">
                                                <input type="text" class="form-control" name="phone" required>
                                                <label class="form-label">Phone</label>
                                            </div>
                                        </div>
                                        <div class="form-group form-float">
                                            <div class="form-line">
                                                <input type="text" class="form-control" name="username" required>
                                                <label class="form-label">Username </label>
                                            </div>
                                        </div>    
                                        <div class="form-group form-float">
                                            <div class="form-line">
                                                <input type="password" class="form-control" name="password" required>
                                                <label class="form-label">Password</label>
                                            </div>
                                        </div>

                                        
                                        <!-- <div class="form-group">
                                            <input type="checkbox" id="checkbox" name="checkbox">
                                            <label for="checkbox">I have read and accept the terms</label>
                                        </div> -->
                                        <button class="btn btn-primary waves-effect" type="submit" name="submit">SUBMIT</button>
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <?php
    if(isset($_POST['submit'])){
        $name=$_POST['name'];
        $email=$_POST['email'];
        $contact=$_POST['phone'];
        $username=$_POST['username'];
        $password=$_POST['password'];

        $result=mysqli_query($conn, "INSERT INTO `employee`(`name`, `contact`, `email`, `username`, `password`) VALUES ('$name','$contact','$email','$username','$password')") or die(mysqli_error($conn));
        $result1=mysqli_query($conn, "INSERT INTO `login`(`username`, `password`,`status`) VALUES ('$username','$password','employee')") or die(mysqli_error($conn));
        echo "<script> window.location = 'view_employee.php' </script>";
    }


?>




<div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
    <h4 class="modal-title">Update profile</h4>
  </div>
  <div class="modal-body">
    <div class="row">
      <div class="col-md-12">
        <div class="fetched-data"></div>
      </div>
    </div>
  </div>
  <div class="modal-footer">
    <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
    <button type="submit" name="register" alt="Login" value="Submit" class="btn blue">Save changes</button>
 </div>
</div>

        <?php
    if(isset($_POST['update'])){
        $id=$_POST['id'];
        $name_u=$_POST['name_u'];
        $email_u=$_POST['email_u'];
        $contact_u=$_POST['phone_u'];
        $username_u=$_POST['username_u'];
        $password_u=$_POST['password_u'];

        $result=mysqli_query($conn, "UPDATE `employee` SET `name`='$name_u',`contact`='$contact_u',`email`='$email_u',`username`='$username_u',`password`='$password_u' WHERE emp_id='$id'") or die(mysqli_error($conn));
        echo "<script> window.location = 'view_employee.php' </script>";
    }


?>
<script>
$(document).ready(function(){
    $('#myModal').on('show.bs.modal', function (e) {
        var rowid = $(e.relatedTarget).data('id');
        alert("hii");
        $.ajax({
            type : 'post',
            url : 'fetch.php', //Here you will fetch records 
            data :  'rowid='+ rowid, //Pass $id
            success : function(data){
            $('.fetched-data').html(data);//Show fetched data from database
            }
        });
     });
});
</script>


        <!-- edit employee Modal -->
        


    <!-- Jquery Core Js -->
    <script src="../plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="../plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="../plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="../plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="../plugins/node-waves/waves.js"></script>
    <script src="../plugins/jquery-validation/jquery.validate.js"></script>
    <script src="../js/pages/forms/form-validation.js"></script>
    <!-- Jquery DataTable Plugin Js -->
    <script src="../plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="../plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

    <!-- Custom Js -->
    <script src="../js/admin.js"></script>
    <script src="../js/pages/tables/jquery-datatable.js"></script>

    <!-- Demo Js -->
    <script src="../js/demo.js"></script>
  
    

</html>
