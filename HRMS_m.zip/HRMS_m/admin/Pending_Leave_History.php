<?php
session_start();
if(!isset($_SESSION["id"])){
	echo "<script>window.location.href='index.php';</script>";
}
$username=$_SESSION['name'];



?>

<?php include 'config.php' ?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>MOXIEDECK HRMS</title>
    <!-- Favicon-->
    <link rel="icon" href="../images/favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="../plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="../plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="../plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- JQuery DataTable Css -->
    <link href="../plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Custom Css -->
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/custom.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="../css/themes/all-themes.css" rel="stylesheet" />
</head>
<?php $result = mysqli_query($conn,"SELECT * FROM apply_leave1");
?>




<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
   <?php include './header.php' ?>

    <section class="content">
        <div class="container-fluid">
           
            <!-- Exportable Table -->
           <!-- Striped Rows -->
           <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                               Pending Leave History
                                <!-- <small>Use <code>.table-striped</code> to add zebra-striping to any table row within the <code>&lt;tbody&gt;</code></small> -->
                            </h2>
                            
                            <div class="header-dropdown m-r--5">
                            <!-- <a class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus" style="color:white" aria-hidden="true"></i>&nbsp;Add Employee</a> -->
                        </div>
                        </div>
                        <div class="body table-responsive">
                        <?php
if (mysqli_num_rows($result) > 0) {
?>
                            <table class="table table-striped dataTable js-exportable">
                            <thead>
                            <tr>
                            
	    <th>#</th>
        <th> ID</th>
        <th>Employee ID</th>
		<th>Name</th>
		<!-- <th>Last Name</th> -->
		<th>Leave_type</th>
        <th>Apply_date</th>
        
		<th>Status</th>
		<th>Action</th> 
        <th>Delete</th> 
	  </tr>
      </thead>
      <tbody>
			<?php
			$i=1;
			while($row = mysqli_fetch_array($result)) {
			?>
	  <tr>
      <th scope="row"><?php echo $i ?></th>
	    <td><?php echo $row["id"]; ?></td>
        <td><?php echo $row["emp_id"]; ?></td>
		<td><?php echo $row["name"]; ?></td>
		<td><?php echo $row["leave_type"]; ?></td>
       

        <td><?php echo $row["apply_date"]; ?></td>
       <td><span style="color: green"><?php 
                                    if($row['approval']=="Approved")
                                    {
                                        echo "<p>Approved</p>";
                                    }?></span>

                                    <span style="color: red">
                                    <?php
                                    if($row['approval']=="Reject")
                                    {
                                        echo "<p>Reject</p>";
                                    }
                                    ?></span>

                                    <span style="color: blue">
                                    <?php
                                    if($row['approval']=="")
                                    {
                                        echo "<p>Waiting for Approval</p>";
                                    }
                                        
                                            
                                 ?></span></td>
		
    

       <td> <a class="btn btn-primary" href="admin_action.php?ids=<?php echo $row["id"]; ?>"></i>&nbsp;View Details</a>
</td>
               
</td>
<!-- <td><a href="admin_action.php?ids=<?php echo $row["id"]; ?>"class="delete" data-id="<?php echo $row["id"]; ?>" data-toggle="modal"><i class="material-icons" data-toggle="tooltip"  -->
						 <!-- title="Delete">&#xE872;</em></a></td> -->
<td><a href="delete.php?ids=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure to delete?')"><i class="fa fa-trash-o" data-toggle="tooltip" title="Delete" style="color:red;" aria-hidden="true"></i></td>

      </tr>
			<?php
			$i++;
			}
			?>

</tbody>           
</table> 

                                

                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Striped Rows -->
        </div>
    </section>
    

        

        <!-- edit employee Modal -->
        


    <!-- Jquery Core Js -->
    <script src="../plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="../plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="../plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="../plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="../plugins/node-waves/waves.js"></script>
    <script src="../plugins/jquery-validation/jquery.validate.js"></script>
    <script src="../js/pages/forms/form-validation.js"></script>
    <!-- Jquery DataTable Plugin Js -->
    <script src="../plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="../plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="../plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

    <!-- Custom Js -->
    <script src="../js/admin.js"></script>
    <script src="../js/pages/tables/jquery-datatable.js"></script>

    <!-- Demo Js -->
    <script src="../js/demo.js"></script>
    <script>
        $(document).ready(function(){
            $('#myModal').on('show.bs.modal', function (e) {
                var rowid = $(e.relatedTarget).data('id');
                // alert(rowid);
                $.ajax({
                    type : 'post',
                    url : 'fetch.php', //Here you will fetch records 
                    data :  'rowid='+ rowid, //Pass $id
                    success : function(data){
                    $('.fetched-data').html(data);//Show fetched data from database
                    }
                });
            });
        });
</script>
</body>

</html>
<?php
}
?>