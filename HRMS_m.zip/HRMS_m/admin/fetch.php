<?php
include './config.php';
  $editId = $_POST['rowid'];
  // echo $editId;
  // exit;
  
  $result = mysqli_query($conn, "select * from employee where emp_id='$editId'") or die(mysqli_error($conn));

  while($row=mysqli_fetch_array($result)){
    $name=$row['name'];
    $email=$row['email'];
    $contact=$row['contact'];
    $username=$row['username'];
    $password=$row['password'];

  }
?>
                        <div class="card">
                                <div class="header">
                                    <h2>Update Employee Details</h2>
                                    
                                </div>
                                <div class="body">
                                    <form id="form_validation" method="POST">
                                    <input type="hidden" class="form-control" name="id" value=<?php echo $editId ?> required>
                                        <div class="form-group form-float">
                                            <div class="form-line">
                                                <input type="text" class="form-control" name="name_u" value="<?php echo $name ?>" required>
                                                <!-- <label class="form-label">Employee Name</label> -->
                                            </div>
                                        </div>
                                        <div class="form-group form-float">
                                            <div class="form-line">
                                                <input type="email" class="form-control" name="email_u" value=<?php echo $email ?> required>
                                                <!-- <label class="form-label">Email</label> -->
                                            </div>
                                        </div>
                                        <div class="form-group form-float">
                                            <div class="form-line">
                                                <input type="text" class="form-control" name="phone_u" value=<?php echo $contact ?> required>
                                                <!-- <label class="form-label">Phone</label> -->
                                            </div>
                                        </div>
                                        <div class="form-group form-float">
                                            <div class="form-line">
                                                <input type="text" class="form-control" name="username_u" value=<?php echo $username ?> required>
                                                <!-- <label class="form-label">Username </label> -->
                                            </div>
                                        </div>    
                                        <div class="form-group form-float">
                                            <div class="form-line">
                                                <input type="password" class="form-control" name="password_u" value=<?php echo $password ?> required>
                                                <!-- <label class="form-label">Password</label> -->
                                            </div>
                                        </div>

                                        
                                        <!-- <div class="form-group">
                                            <input type="checkbox" id="checkbox" name="checkbox">
                                            <label for="checkbox">I have read and accept the terms</label>
                                        </div> -->
                                        <button class="btn btn-primary waves-effect" type="submit" name="update">SUBMIT</button>
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                    </form>
                                </div>
                            </div>