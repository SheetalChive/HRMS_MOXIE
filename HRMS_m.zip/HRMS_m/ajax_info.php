<?php 

$type=$_GET['type'];

if($type === "Other"){
    echo "<textarea class='form-control' id='other' name='other' cols='10' rows='2'></textarea>";
}
