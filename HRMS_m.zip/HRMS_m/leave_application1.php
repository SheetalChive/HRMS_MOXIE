<?php
session_start();
if(!isset($_SESSION["id"])){
	echo "<script>window.location.href='index.php';</script>";
}
$loginid=$_SESSION["id"];
$username=$_SESSION['name'];
include './config.php';
$query=mysqli_query($conn,"select * from employee where username='$username'") or die (mysqli_error($conn));
$result=mysqli_fetch_array($query);
$name=$result['name'];
$id=$result['emp_id'];
$dept=$result['department'];
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Basic Form Elements | Bootstrap Based Admin Template - Material Design</title>
    <!-- Favicon-->
    <link rel="icon" href="images/favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Bootstrap Material Datetime Picker Css -->
    <link href="plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet" />

    <!-- Bootstrap DatePicker Css -->
    <link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet" />

    <!-- Wait Me Css -->
    <link href="plugins/waitme/waitMe.css" rel="stylesheet" />

    <!-- Bootstrap Select Css -->
    <link href="plugins/bootstrap-select/css/bootstrap-select.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="css/themes/all-themes.css" rel="stylesheet" />
</head>
<script>
$("#btn").bind("click", function() {
  alert("Event 1");
});
</script>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <?php include './header.php' ?>

    <section class="content">
        <div class="container-fluid">
            <!-- <div class="block-header">
                <h2>BASIC FORM ELEMENTS</h2>
            </div> -->
           
            
            <!-- Select -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                            Application For The Leave
                               
                            </h2>
                            
                        </div>
                        <div class="body">
                        <div class="body">
                            <form id="form_validation" method="POST">


                            <div class="row clearfix">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="date" value="<?php echo date("Y-d-m"); ?>">
                                        <label class="form-label">Application Date</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="emp_id" value ="<?php echo "$id" ?>">
                                        <label class="form-label">Employeen ID</label>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row clearfix">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="name" value = "<?php echo "$name" ?>">
                                        <label class="form-label">Employee Name</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                       

                            <div class="row clearfix">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="department" value = "<?php echo "$dept" ?>" required>
                                        <label class="form-label">Depatment</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                               
                                
                                <div class="form-group form-float">
                                <h5>Reason For Requested Leave: (Please tick appropriate box)</h5>
                            <div class="demo-checkbox"  >
                                <input type="checkbox" id="md_checkbox_1" name = "leave_type" />
                                <label for="md_checkbox_1">Annual Leave</label>
                                <input type="checkbox" id="md_checkbox_2"  name = "leave_type" />
                                <label for="md_checkbox_2">Bereavement</label>
                                <input type="checkbox" id="md_checkbox_3" name = "leave_type" />
                                <label for="md_checkbox_3">Maternity Leave</label>
                                <input type="checkbox" id="md_checkbox_4" name = "leave_type" />
                                <label for="md_checkbox_4">Half Day</label>
                                <input type="checkbox" id="md_checkbox_5" name = "leave_type"  />
                                <label for="md_checkbox_5">Sick Leave</label>
                                <input type="checkbox" id="md_checkbox_6" name = "leave_type"  />
                                <label for="md_checkbox_6">Unpaid Leave</label>
                                <input type="checkbox" id="md_checkbox_7" name = "leave_type"  />
                                <label for="md_checkbox_7">Parental Leave</label>
                                <input type="checkbox" id="md_checkbox_8" name = "leave_type"  />
                                <label for="md_checkbox_7">Other</label>
                               <br><br><br>

                               <div class="row clearfix">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text"  name="description" class="form-control"  required>
                                        <label class="form-label">Description</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div><br>
                                
                                <div class="row clearfix">
                                <div class="col-md-3">
                                    <b>From</b>
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <!-- <i class="material-icons">date_range</i> -->
                                        </span>
                                        <div class="form-line">
                                            <input type="date"  name="from_date" class="form-control date" placeholder="Ex: 30/07/2016">
                                        </div>
                                    </div>
                                    
                                    </div>

                                    <div class="col-md-3">
                                        <b>TO</b>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <!-- <i class="material-icons">date_range</i> -->
                                            </span>
                                            <div class="form-line">
                                                <input type="date" name="to_date" class="form-control time24" placeholder="Ex: 30/07/2016">
                                            </div>
                                        </div>
                                    </div>
                                  <br><br><br><br>
                             
                                <button class="btn btn-primary waves-effect" type="submit" name="submit">SUBMIT</button>
                            </form>   
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Select -->
         </div>

    </section>
   

    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Autosize Plugin Js -->
    <script src="plugins/autosize/autosize.js"></script>

    <!-- Moment Plugin Js -->
    <script src="plugins/momentjs/moment.js"></script>

    <!-- Bootstrap Material Datetime Picker Plugin Js -->
    <script src="plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

    <!-- Bootstrap Datepicker Plugin Js -->
    <script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/forms/basic-form-elements.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>
</body>
</html>

<?php

if(isset($_POST['submit']))
{
    $apply_date      =   $_POST['date'];
    $emp_id          =   $_POST['emp_id'];
    $name            =   $_POST['name'];
    $department      =   $_POST['department']; 
    $leave_type      =   $_POST['leave_type']; 
    $description     =   $_POST['description'] ;
    $from_date       =   $_POST['from_date'];
    $to_date        =   $_POST['to_date']; 
    
    
// $status=0;
// $isread=0;
// if($fromdate > $todate){
//                 $error=" ToDate should be greater than FromDate ";
//            }
// $sql="INSERT INTO leave(apply_date,emp_id,name,department,leave_type,description,from_date,to_type) VALUES(:apply_date,:id,:name,:todate,:dept,:desc,:from,:to)";


$result=mysqli_query($conn, "INSERT INTO `leave` SET `apply_date`='$apply_date',`emp_id`='$emp_id',`name`='$name',`department`='$department',`leave_type`='$leave_type',`from_date`='$from_date',`to_date`='$to_date'") or die(mysqli_error($conn));
// $query = $dbh->prepare($sql);
// $query->bindParam(':apply_date',$apply_date,PDO::PARAM_STR);
// $query->bindParam(':emp_id',$emp_id,PDO::PARAM_STR);
// $query->bindParam(':name',$name,PDO::PARAM_STR);
// $query->bindParam(':department',$department,PDO::PARAM_STR);
// $query->bindParam(':leave_type',$leave_type,PDO::PARAM_STR);
// $query->bindParam(':description',$description,PDO::PARAM_STR);
// $query->bindParam(':from_date',$from_date,PDO::PARAM_STR);
// $query->bindParam(':to_date',$to_date,PDO::PARAM_STR);

$result->execute();
// $lastInsertId = $dbh->lastInsertId();
if($result)
{
$msg="Leave applied successfully";
}
else 
{
$error="Something went wrong. Please try again";
}


}
    ?>