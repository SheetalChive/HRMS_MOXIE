<?php
session_start();
if(!isset($_SESSION["id"])){
	echo "<script>window.location.href='index.php';</script>";
}
$loginid=$_SESSION["id"];
$username=$_SESSION['name'];
include 'config.php';
$query=mysqli_query($conn,"select * from employee where username='$username'") or die (mysqli_error($conn));
$result=mysqli_fetch_array($query);
$name=$result['name'];
$id=$result['emp_id'];
$dept=$result['department'];
// $date=date("y-d-m");
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Basic Form Elements | Bootstrap Based Admin Template - Material Design</title>
    <!-- Favicon-->
    <link rel="icon" href="images/favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Bootstrap Material Datetime Picker Css -->
    <link href="plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet" />

    <!-- Bootstrap DatePicker Css -->
    <link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet" />

    <!-- Wait Me Css -->
    <link href="plugins/waitme/waitMe.css" rel="stylesheet" />

    <!-- Bootstrap Select Css -->
    <link href="plugins/bootstrap-select/css/bootstrap-select.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="css/themes/all-themes.css" rel="stylesheet" />



    
</head>
<script>
$("#btn").bind("click", function() {
  alert("Event 1");
});
</script>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <?php include './header.php' ?>

    <section class="content">
        <div class="container-fluid">
            <!-- <div class="block-header">
                <h2>BASIC FORM ELEMENTS</h2>
            </div> -->
           
            
            <!-- Select -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                             Leave History
                               
                            </h2>
                            
                        </div>
                        <div class="body table-responsive">
                            <table class="table table-striped dataTable js-exportable">
                            <thead>
                            <tr>
                            
	    <th>#</th>
       
        
		<th>Name</th>
		<!-- <th>Last Name</th> -->
		<th>Admin Action</th>
        <th>Extended Leave Date</th>
        
		<th>Status</th>
		<!-- <th>Action</th> 
        <th>Delete</th>  -->
	  </tr>
      </thead>
        <tbody>
                    <?php include 'config.php';
                            //    $loginid=$_SESSION["id"];
                            //    $username=$_SESSION['name'];
                               
                            $username=$_SESSION['name'];

                                $query1=mysqli_query($conn,"select * from employee where username='$username'") or die (mysqli_error($conn));
                              
                                $row1 = mysqli_fetch_array($query1);
                                  $loginid = $row1["emp_id"];

                                    $query = mysqli_query($conn,"select * from apply_leave1 where emp_id = $loginid");
                                    $result=mysqli_num_rows($query);
                                    $count = 1;
                                    for($i = 1; $i<= $result;$i++)
                                    {
                                        $row = mysqli_fetch_array($query);
                                        // print_r($row);
                                  
       
   
                                ?>


<tr>
	    <td><?php echo $row["id"]; ?></td>
        
		<td><?php echo $row["name"]; ?></td>
		<td><?php echo $row["admin_action"]; ?></td>
       

        <td><?php echo $row["extended_date_from"];   ?> <b> TO </b> <?php echo $row["extended_date_to"]; ?></td>
        <td><span style="color: green"><?php 
                                    if($row['approval']=="Approved")
                                    {
                                        echo "<p>Approved</p>";
                                    }?></span>

                                    <span style="color: red">
                                    <?php
                                    if($row['approval']=="Reject")
                                    {
                                        echo "<p>Reject</p>";
                                    }
                                    ?></span>

                                    <span style="color: blue">
                                    <?php
                                    if($row['approval']=="")
                                    {
                                        echo "<p>Waiting for Approval</p>";
                                    }
                                        
                                            
                                 ?></span></td>
		                               

    <?php
                                    }
    ?>

    </tbody>

</table>

                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Select -->
         </div>

    </section>
  

    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Autosize Plugin Js -->
    <script src="plugins/autosize/autosize.js"></script>

    <!-- Moment Plugin Js -->
    <script src="plugins/momentjs/moment.js"></script>

    <!-- Bootstrap Material Datetime Picker Plugin Js -->
    <script src="plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

    <!-- Bootstrap Datepicker Plugin Js -->
    <script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/forms/basic-form-elements.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>
    <script>
        $(document).ready(function(){
            $('#myModal').on('show.bs.modal', function (e) {
                var rowid = $(e.relatedTarget).data('id');
                // alert(rowid);
                $.ajax({
                    type : 'post',
                    url : 'fetch.php', //Here you will fetch records 
                    data :  'rowid='+ rowid, //Pass $id
                    success : function(data){
                    $('.fetched-data').html(data);//Show fetched data from database
                    }
                });
            });
        });
</script>
</body>
</html>
