-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2021 at 06:52 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hrms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_action`
--

CREATE TABLE `admin_action` (
  `id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `admin_action` varchar(255) NOT NULL,
  `leave_date_from` date NOT NULL,
  `leave_date_to` date NOT NULL,
  `approval` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_action`
--

INSERT INTO `admin_action` (`id`, `emp_id`, `name`, `admin_action`, `leave_date_from`, `leave_date_to`, `approval`) VALUES
(13, 5, 'arti', ' ddddd', '2021-04-07', '2021-04-08', 'Reject'),
(14, 34, 'kiran', ' xvc', '2021-03-31', '2021-04-07', 'Approved'),
(16, 5, 'arti', ' hrllo', '2021-04-01', '2021-04-08', 'Reject'),
(17, 34, 'kiran', ' iiouou', '2021-03-30', '2021-04-07', 'Approved'),
(18, 34, 'kiran', ' aaaaaaaaaaaaaaaaaaaaaaaaaaa', '2021-04-06', '2021-04-09', 'Approved'),
(19, 5, 'arti', ' afd', '2021-03-28', '2021-03-30', 'Approved'),
(20, 34, 'kiran', ' DHG', '2021-03-29', '2021-03-31', 'Approved'),
(0, 3, 'akshay kadam', ' cvbvc', '2021-03-30', '2021-03-31', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `apply_leave`
--

CREATE TABLE `apply_leave` (
  `id` int(11) NOT NULL,
  `apply_date` date NOT NULL,
  `emp_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `leave_type` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `apply_leave`
--

INSERT INTO `apply_leave` (`id`, `apply_date`, `emp_id`, `name`, `department`, `leave_type`, `description`, `from_date`, `to_date`) VALUES
(21, '2021-03-29', 5, 'arti', 'Digital Marketing', 'Annual Leave,', 'sadasd', '2021-03-24', '2021-03-31'),
(22, '2021-03-29', 34, 'kiran', 'Digital Marketing', 'Unpaid Leave,', 'ww', '2021-04-07', '2021-04-08'),
(23, '2021-03-29', 34, 'kiran', 'it', 'Annual Leave,', 'dgfd', '2021-04-07', '2021-04-08'),
(24, '2021-03-29', 5, 'arti', 'e', 'Parental Leave,', 'ddd', '2021-04-01', '2021-04-08'),
(25, '2021-03-30', 5, 'arti', 'Digital Marketing', 'Annual Leave,', 'sfdg', '2021-03-29', '2021-03-31'),
(26, '2021-03-30', 34, 'kiran', 'sfdsg', 'Annual Leave,', 'dgbd', '2021-03-31', '2021-04-01'),
(27, '2021-03-30', 34, 'kiran', 'Digital Marketing', 'Annual Leave,', 'DHG', '2021-03-29', '2021-03-31'),
(0, '2021-03-30', 3, 'akshay kadam', 'IT', 'Sick Leave,', 'jgasdh', '2021-03-30', '2021-04-01');

-- --------------------------------------------------------

--
-- Table structure for table `apply_leave1`
--

CREATE TABLE `apply_leave1` (
  `id` int(11) NOT NULL,
  `apply_date` date NOT NULL,
  `emp_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `leave_type` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `admin_action` varchar(255) DEFAULT NULL,
  `extended_date_from` date DEFAULT NULL,
  `extended_date_to` date DEFAULT NULL,
  `approval` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `apply_leave1`
--

INSERT INTO `apply_leave1` (`id`, `apply_date`, `emp_id`, `name`, `department`, `leave_type`, `description`, `from_date`, `to_date`, `admin_action`, `extended_date_from`, `extended_date_to`, `approval`) VALUES
(1, '2021-03-30', 34, 'kiran', 'sfdsg', 'Annual Leave,', 'sfdg', '2021-03-25', '2021-04-07', NULL, NULL, NULL, NULL),
(2, '2021-03-30', 34, 'kiran', 'Digital Marketing', 'Annual Leave,', 'zdf', '2021-03-29', '2021-03-31', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `break`
--

CREATE TABLE `break` (
  `id` int(11) NOT NULL,
  `break type` varchar(255) NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `end_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `break`
--

INSERT INTO `break` (`id`, `break type`, `start_time`, `end_time`) VALUES
(1, 'dinner', '2021-03-24 18:48:56', '0000-00-00 00:00:00'),
(2, 'Lunch', '2021-03-24 18:49:34', '0000-00-00 00:00:00'),
(3, 'Tea break', '2021-03-24 18:49:34', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`emp_id`, `name`, `contact`, `email`, `username`, `password`) VALUES
(1, 'Rushikesh Wadekar', '9854758485', 'rushi112@gmail.com', 'rushi@112', 'rushi@123'),
(3, 'akshay kadam', '8745985695', 'kadam@gmail.com', 'akadam@121', 'akshay@121');

-- --------------------------------------------------------

--
-- Table structure for table `emp_schedule`
--

CREATE TABLE `emp_schedule` (
  `id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `other` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `starttime` varchar(255) NOT NULL,
  `endtime` varchar(255) NOT NULL,
  `totaltime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emp_schedule`
--

INSERT INTO `emp_schedule` (`id`, `login_id`, `username`, `category`, `other`, `date`, `starttime`, `endtime`, `totaltime`) VALUES
(1, 1, 'akadam@121', 'Login', '', '2021-03-29', '12:13:12AM', '12:13:32AM', '0:0:20'),
(2, 1, 'akadam@121', 'Other', 'Washroom', '2021-03-29', '12:25:35AM', '12:25:47AM', '0:0:12'),
(3, 1, 'akadam@121', 'Other', 'wadfdf', '2021-03-29', '12:51:5AM', '12:59:4AM', '0:0:0'),
(4, 1, 'akadam@121', 'Other', 'tp', '2021-03-29', '13:0:35PM', '13:0:44PM', '0:0:0'),
(5, 1, 'akadam@121', 'Login', '', '2021-03-29', '13:13:24PM', '13:14:4PM', '0:0:0'),
(6, 1, 'akadam@121', 'Tea Break', '', '2021-03-29', '13:16:15PM', '13:16:35PM', '0'),
(7, 1, 'akadam@121', 'Tea Break', '', '2021-03-29', '01:00:00 am 01/01/1970', '0', '0'),
(8, 1, 'akadam@121', 'Login', '', '2021-03-29', '14:38:28PM', '14:38:37PM', '0'),
(9, 1, 'akadam@121', 'Login', '', '2021-03-29', '2:49:16PM', '2:50:16PM', '60'),
(10, 1, 'akadam@121', 'Tea Break', '', '2021-03-29', '2:50:54PM', '2:56:42PM', '0:5:48'),
(11, 1, 'akadam@121', 'Other', 'Washroom', '2021-03-29', '2:57:5PM', '8:47:22AM', '449190:47:22'),
(12, 1, 'akadam@121', 'Other', 'xyz', '2021-03-30', '8:48:24AM', '8:48:58AM', '0:0:34'),
(13, 1, 'akadam@121', 'Login', '-', '2021-03-30', '8:57:45AM', '8:58:24AM', '0:0:39'),
(14, 1, 'akadam@121', 'Login', '-', '2021-03-30', '9:0:33AM', '9:1:14AM', '0:0:41'),
(15, 1, 'akadam@121', 'Other', '-', '2021-03-30', '9:1:34AM', '9:2:45AM', '0:1:11'),
(16, 1, 'akadam@121', 'TL Meeting', '', '2021-03-30', '9:3:4AM', '9:3:43AM', '449191:3:43'),
(17, 1, 'akadam@121', 'Event', '', '2021-03-30', '9:4:4AM', '9:5:16AM', '449191:5:16'),
(18, 1, 'akadam@121', 'Dinner', '', '2021-03-30', '9:8:24AM', '9:9:17AM', '0:0:53'),
(19, 1, 'akadam@121', 'SME Meeting', '', '2021-03-30', '9:9:45AM', '9:10:26AM', '0:0:41'),
(20, 1, 'akadam@121', '', '', '2021-03-30', '9:17:3AM', '0', '0'),
(21, 1, 'akadam@121', '', '', '2021-03-30', '9:17:58AM', '9:18:14AM', '0:0:16'),
(22, 1, 'akadam@121', '', '', '2021-03-30', '9:20:50AM', '9:21:9AM', '-449192:-20:-50'),
(23, 1, 'akadam@121', 'Training', '', '2021-03-30', '9:22:57AM', '9:23:39AM', '0:0:42'),
(24, 1, 'akadam@121', 'TL Meeting', '', '2021-03-30', '9:32:55AM', '9:33:14AM', '0:0:19'),
(25, 1, 'akadam@121', 'Tea Break', '', '2021-03-30', '4:16:47PM', '4:16:56PM', '0:0:9'),
(26, 1, 'akadam@121', 'Login', '', '2021-03-31', '9:0:58AM', '9:1:45AM', '0:0:47');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `status`) VALUES
(1, 'akadam@121', 'akshay@121', 'employee'),
(2, 'admin', '1234', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `emp_schedule`
--
ALTER TABLE `emp_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `emp_schedule`
--
ALTER TABLE `emp_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
