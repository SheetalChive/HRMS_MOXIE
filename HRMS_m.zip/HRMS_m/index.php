<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="css/loginstyle.css">
<script type="text/javascript" rel="stylesheet" src="main.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container register">
                <div class="row">
                    <div class="col-md-3 register-left">
                        <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt=""/>
                        <h3>Welcome</h3>
                        <p>Welcome to the Moxiedeck Software..</p>
                       
                        <!-- <input type="submit" name="" value="Login"/><br/> -->
                    </div>
                    <div class="col-md-9 register-right">
                        <ul class="nav nav-tabs nav-justified" id="myTab" role="tablist">
                            <li class="nav-item">
                                <!-- <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Employee</a> -->
                            </li>
                            <li class="nav-item">
                                <!-- <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Hirer</a> -->
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <h3 class="register-heading">Login to the Moxiedeck</h3>
                                <div class="row register-form">
                                    <div class="col-md-8">
                                    <form action="authenticate.php" method="post">
                                        <div class="form-group">
                                            <!-- <input type="text"class="form-control" placeholder="User Name *" value="" /> -->
                                            <input type="text" class="form-control" name="username" placeholder="Username" id="username" required>
                                        </div>
                                        <!-- <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Last Name *" value="" />
                                        </div> -->
                                        <div class="form-group">
                                            <!-- <input type="password" class="form-control" placeholder="Password *" value="" /> -->
                                            <input type="password" class="form-control" name="password" placeholder="Password" id="password" required>
                                        </div>

                                        <div class="form-group">
                                            <!-- <label for="usertype">Usertype</label> -->
                                            <select name="status" class="form-control" id="usertype">
                                                <option value="">Choose User Type</option>
                                                <option value="admin">Admin</option>
                                                <option value="employee">Employee</option>
                                            </select>
		                                         <small id="t_error" class="form-text text-muted"></small>
		                                </div>
                                         <div class="form-group">
                                         <!-- <input type="submit" class="btnRegister"  value="Login"/> -->
                                         <!-- <button type="submit" name="login" class="btn btn-primary"><i class="fa fa-lock">&nbsp;</i>Login</button> -->
                                            <!-- <input type="password" class="form-control"  placeholder="Confirm Password *" value="" /> -->
                                            <input class="btn btn-info form-control"  type="submit" value="Login">
	                            		</form> 
                                        </div> 
                                       
                                    </div>
                                   
                                
                            </div>

                         
                        </div>
                    </div>
                </div>

            </div>