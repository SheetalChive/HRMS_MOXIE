<?php
session_start();
if(!isset($_SESSION["id"])){
	echo "<script>window.location.href='index.php';</script>";
}
$loginid=$_SESSION["id"];
$username=$_SESSION['name'];
include './config.php';
$query=mysqli_query($conn,"select * from employee where username='$username'") or die (mysqli_error($conn));
$result=mysqli_fetch_array($query);
$name=$result['name'];
$id=$result['emp_id'];
$dept=$result['department'];
// $date=date("y-d-m");
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Basic Form Elements | Bootstrap Based Admin Template - Material Design</title>
    <!-- Favicon-->
    <link rel="icon" href="images/favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Bootstrap Material Datetime Picker Css -->
    <link href="plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet" />

    <!-- Bootstrap DatePicker Css -->
    <link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet" />

    <!-- Wait Me Css -->
    <link href="plugins/waitme/waitMe.css" rel="stylesheet" />

    <!-- Bootstrap Select Css -->
    <link href="plugins/bootstrap-select/css/bootstrap-select.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="css/themes/all-themes.css" rel="stylesheet" />
</head>
<script>
$("#btn").bind("click", function() {
  alert("Event 1");
});
</script>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <?php include './header.php' ?>

    <section class="content">
        <div class="container-fluid">
            <!-- <div class="block-header">
                <h2>BASIC FORM ELEMENTS</h2>
            </div> -->
           
            
            <!-- Select -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                            Application For The Leave
                               
                            </h2>
                            
                        </div>
                        <div class="body">
                        <div class="body">
                            <form id="form_validation" method="POST">


                            <div class="row clearfix">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="apply_date" name = "order_date " value="<?php echo date("Y-d-m"); ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="emp_id" value ="<?php echo "$id" ?>">
                                        <label class="form-label">Employeen ID</label>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row clearfix">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="name" value = "<?php echo "$name" ?>">
                                        <label class="form-label">Employee Name</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                       

                            <div class="row clearfix">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="dept" value = "<?php echo "$dept" ?>" required>
                                        <label class="form-label">Depatment</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                               
                                
                                <div class="form-group form-float">
                                <h5>Reason For Requested Leave: (Please tick appropriate box)</h5>
                            <div class="demo-checkbox">
                                <input type="checkbox" id="md_checkbox_1"  value="Annual Leave" name="checkbox[]" />
                                <label for="md_checkbox_1">Annual Leave</label>
                                <input type="checkbox" id="md_checkbox_2"   value="Bereavement"  name="checkbox[]"  />
                                <label for="md_checkbox_2">Bereavement</label>
                                <input type="checkbox" id="md_checkbox_3"   value="Maternity Leave"  name="checkbox[]" />
                                <label for="md_checkbox_3">Maternity Leave</label>
                                <input type="checkbox" id="md_checkbox_4"   value="Half Day"  name="checkbox[]" />
                                <label for="md_checkbox_4">Half Day</label>
                                <input type="checkbox" id="md_checkbox_5"   value="Sick Leave" name="checkbox[]" />
                                <label for="md_checkbox_5">Sick Leave</label>
                                <input type="checkbox" id="md_checkbox_6"   value="Unpaid Leave" name="checkbox[]" />
                                <label for="md_checkbox_6">Unpaid Leave</label>
                                <input type="checkbox" id="md_checkbox_7"   value="Parental Leave" name="checkbox[]"  />
                                <label for="md_checkbox_7">Parental Leave</label>
                                <input type="checkbox" id="md_checkbox_8"   value="Other"  name="checkbox[]" />
                                <label for="md_checkbox_7">Other</label>
                               
                               
                               
                            </div><br>
                            <div class="row clearfix">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="form-line">
                                        <input type="text" class="form-control" name="description"  required>
                                        <label class="form-label">Description</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <div class="row clearfix">
                                <div class="col-md-3">
                                    <b>From</b>
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <!-- <i class="material-icons">date_range</i> -->
                                        </span>
                                        <div class="form-line">
                                            <input type="date" class="form-control date" name="from_date" placeholder="Ex: 30/07/2016">
                                        </div>
                                    </div>
                                    
                                    </div>

                                    <div class="col-md-3">
                                        <b>TO</b>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <!-- <i class="material-icons">date_range</i> -->
                                            </span>
                                            <div class="form-line">
                                                <input type="date" class="form-control time24" name="to_date" placeholder="Ex: 30/07/2016">
                                            </div>
                                        </div>
                                    </div>
                                  <br><br><br><br>
                             
                                <button class="btn btn-primary waves-effect" type="submit" name="submit">SUBMIT</button>
                            </form>   
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Select -->
         </div>

    </section>
    <?php

    $current_date = date("Y-m-d H:i:s");
    if(isset($_POST['submit'])){
        $apply_date=$_POST['apply_date'];
        $emp_id=$_POST['emp_id'];
        $emp_name=$_POST['name'];
        $department=$_POST['dept'];
        $leave_type=$_POST['checkbox'];
        $description=$_POST['description'];
        $from_date=$_POST['from_date'];
        $to_date=$_POST['to_date'];
       
        
        $checkbox1=$_POST['checkbox'];  
        $chk="";  
        foreach($checkbox1 as $chk1)  
           {  
              $chk .= $chk1.",";  
           }  
           
        $result=mysqli_query($conn, "INSERT INTO `apply_leave1`(`apply_date`, `emp_id`, `name`, `department`, `leave_type`, `description`, `from_date`, `to_date`) VALUES ('$current_date','$emp_id','$emp_name','$department','$chk','$description',' $from_date','$to_date')") or die(mysqli_error($conn));

        if($result==1)  
           {  
              echo'<div class="alert alert-success" role="alert">
              <h4 class="alert-heading">Well done!</h4>
              <p>Your Application has submited successfully.</p>
            
            </div>';  
           }  
        else  
           {  
              echo'<script>alert("Failed To Insert")</script>';  
           }  
       
        echo "<script> window.location = 'leave_application.php' </script>";

        
    }


?>


    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Autosize Plugin Js -->
    <script src="plugins/autosize/autosize.js"></script>

    <!-- Moment Plugin Js -->
    <script src="plugins/momentjs/moment.js"></script>

    <!-- Bootstrap Material Datetime Picker Plugin Js -->
    <script src="plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

    <!-- Bootstrap Datepicker Plugin Js -->
    <script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/forms/basic-form-elements.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>
</body>
</html>
