<?php
session_start();
if(!isset($_SESSION["id"])){
	echo "<script>window.location.href='index.php';</script>";
}
$loginid=$_SESSION["id"];
$username=$_SESSION['name'];
// echo $username;
// exit();
include './config.php';
$query=mysqli_query($conn,"select name from employee where username='$username'") or die (mysqli_error($conn));
$result=mysqli_fetch_array($query);
$name=$result['name'];
$currDate = date("Y/m/d");
?>

<style>
.blink {
  animation: blink 1s steps(1, end) infinite;
}

@keyframes blink {
  0% {
    opacity: 1.0;
  }
  50% {
    opacity: 0.0;
  }
  100% {
    opacity: 1.0;
  }
}
</style>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Basic Form Elements | Bootstrap Based Admin Template - Material Design</title>
    <!-- Favicon-->
    <link rel="icon" href="images/favicon.png" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Bootstrap Material Datetime Picker Css -->
    <link href="plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet" />

    <!-- Bootstrap DatePicker Css -->
    <link href="plugins/bootstrap-datepicker/css/bootstrap-datepicker.css" rel="stylesheet" />

    <!-- Wait Me Css -->
    <link href="plugins/waitme/waitMe.css" rel="stylesheet" />

    <!-- Bootstrap Select Css -->
    <link href="plugins/bootstrap-select/css/bootstrap-select.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="css/themes/all-themes.css" rel="stylesheet" />
</head>
<script>
function myFunction() {
    var x = document.getElementById("type").value;
    // alert(x);
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     document.getElementById("demo").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "ajax_info.php?type="+ x, true);
  xhttp.send();
}
</script>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <?php include './header.php' ?>

    <section class="content">
        <div class="container-fluid">
            <!-- <div class="block-header">
                <h2>BASIC FORM ELEMENTS</h2>
            </div> -->


            <!-- Select -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                            Your Schedule

                            </h2>

                        </div>
                        <!-- <div class="header"> -->
                        <p></p>
                        <br><p> &nbsp; &nbsp; &nbsp;<span style="color: Red" class="blink"> Warnning  :  Select shedule first before start your activity.</span></p>
                            <!-- <br><p> &nbsp; &nbsp; &nbsp; <span style="color: Red"> Warnning  :  Select shedule first before start your activity.</span></p> -->
                        <!-- </div> -->
                        <div class="body">

                                <form method="post">
                                <div class="row clearfix">
                                        <input type="hidden" name="username" id="user_id" value="<?php echo $username; ?>">
                                        <div class="col-sm-5 selectBox">
                                            <select name="category" id="type" onchange="myFunction()" class="form-control show-tick" required>
                                                <option value="">-- Please select --</option>
                                                <option value="Login">Login</option>
                                                <option value="Tea Break">Tea Break</option>
                                                <option value="Lunch">Lunch</option>
                                                <option value="Dinner">Dinner</option>
                                                <option value="TL Meeting">TL Meeting</option>
                                                <option value="SME Meeting">SME Meeting</option>
                                                <option value="Training">Training</option>
                                                <option value="Event">Event</option>
                                                <option value="Other">Other Activity</option>
                                                <option value="logout">Logout</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="col-sm-3">
                                                <center>	<iframe src="http://free.timeanddate.com/clock/i616j2aa/n1993/szw160/szh160/cf100/hnce1ead6" frameborder="0" width="160" height="160"></iframe></center>
                                                    <div id=n1 style="display:none;">
                                                    </div>
                                                    <input type="hidden" name="starttime" id="starttime" value="" />
                                            </div>
                                        
                                            <div class="col-sm-3 col-md-offset-1 actionButton">
                                                <!-- <input type="button" name="start" class="btn btn-success start" id='btn' value="Start" onclick="to_start()";> -->
                                                <!-- <input type="submit" name="start" class="btn btn-success start" id='btn' value="Start" > -->
                                                <input type="button" name="start" class="btn btn-success start" id='btn' value="Start"  onclick="data_check()";> 
                                                <!-- <input onclick="data_check()"; value="Submit Form" type="b utton">  -->


                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                            <div id="demo">
                                            </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Select -->


             <!-- Striped Rows -->
           <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                               Your Daily Schedule
                                <!-- <small>Use <code>.table-striped</code> to add zebra-striping to any table row within the <code>&lt;tbody&gt;</code></small> -->
                            </h2>


                        </div>
                        
                        <div class="body table-responsive">
                            <table class="table table-striped dataTable js-exportable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <!-- <th>NAME</th> -->
                                        <th>CATEGORY</th>
                                        <th>DATE</th>
                                        <th>START TIME</th>
                                        <th>END TIME</th>
                                        <th>BUFFER TIME</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php include './config.php';
                                    $query = mysqli_query($conn,"select * from emp_schedule where username='$username' and date='$currDate'");
                                    $count = 1;
                                    while($row =mysqli_fetch_array($query)){

                                    ?>

                                    <tr>
                                        <th scope="row"><?php echo $count ?></th>
                                        <!-- <td>-->
                                        <?php
                                        // $q=mysqli_query($conn,"SELECT `name` FROM `employee` WHERE `username`='$username'") or die(mysqli_error($conn));
                                        // $result=mysqli_fetch_array($q);
                                        // echo $result['name'];
                                        ?>
                                        <!-- </td> -->
                                        <td><?php echo $row['category']."--".$row['other']; ?></td>
                                        <td><?php echo $row['date']; ?></td>
                                        <td><?php echo $row['starttime']; ?></td>
                                        <td><?php echo $row['endtime']; ?></td>
                                        <td><?php echo $row['totaltime']; ?></td>
                                    </tr>
                                <?php

                                $count ++;
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Striped Rows -->


         </div>

    </section>
    <script language=javascript>

    document.getElementById('btn').addEventListener('click', function(){

    to_start();

});

// var d1 = new date("h:i:sa");
var d = new Date();
var h = d.getHours();
var m = d.getMinutes();
var s = d.getSeconds();
var dd = "AM";

function to_start(){
    

switch(document.getElementById('btn').value)
{
case  'Stop':
// alert("stop");
window.clearInterval(tm); // stop the timer
document.getElementById('btn').value='Start';
document.getElementById('btn').setAttribute("class", "btn btn-success stop");
function3()
location.reload();
location.reload();
break;
case  'Start':
    
tm=window.setInterval('disp()',1000);
function2();
document.getElementById('btn').value='Stop';
document.getElementById('btn').setAttribute("class", "btn btn-danger start");


break;
}

}

function disp(){
// Format the output by adding 0 if it is single digit //
if(s<10){var s1='0' + s;}
else{var s1=s;}
if(m<10){var m1='0' + m;}
else{var m1=m;}
if(h<10){var h1='0' + h;}
else{var h1=h;}

if (h = h% 12 ) {
    // // h = hh - 12;
    dd = "PM";
  }
// Display the output //
str= h + ':' + m1 +':' + s1 + dd ;
document.getElementById('n1').innerHTML= str;
document.getElementById('starttime').value =str;

// Calculate the stop watch //
if(s<59){
s=s+1;
}else{
s=0;
m=m+1;
if(m==60){
m=0;
h=h+1;
} // end if  m ==60

}// end if else s < 59
// end of calculation for next display

}
function function2(){
    var username=document.getElementById("user_id").value;
    var category=document.getElementById("type").value;
    var starttime=document.getElementById("starttime").value;
   
    // if(category === null){
    //     alert("Please Select Activity 1st");
    //     return false;
    // }else
    if(category === 'Other'){
        var other=document.getElementById("other").value;
    }

    console.log(category);

    if(starttime !== null && starttime !== '') {
        var starttime=document.getElementById("starttime").value;

    }else{
        var d = new Date();
        var h = d.getHours();
        var m = d.getMinutes();
        var s = d.getSeconds();

        // alert(h);
        if(h<=12){
            var dd = "AM";
        }else{
            var dd = "PM";
        }
        if (h = h% 12 ) {
            // // h = hh - 12;
            // dd = "PM";
        }
       var starttime = h + ':' + m +':' + s + dd ;

    }
    console.log(starttime);
    $.ajax({
            url:"tracker1.php",    //the page containing php script
            type: "post",    //request type,
            dataType: 'json',
            data: {user_id: username, category: category, starttime: starttime, type: 'start'},
            success:function(result){
                console.log(result.abc);
            }
        });

}

function function3(){
    var username=document.getElementById("user_id").value;
    var category=document.getElementById("type").value;
    var starttime=document.getElementById("starttime").value;

    var d = new Date();
        var h = d.getHours();
        var m = d.getMinutes();
        var s = d.getSeconds();
        var dd = "PM";
        // alert(h);
        if(h<=12){
            var dd = "AM";
        }else{
            var dd = "PM";
        }
        if (h = h% 12 ) {
            // // h = hh - 12;
            // dd = "PM";
        }
       var starttime = h + ':' + m +':' + s + dd ;

    $.ajax({
            url:"tracker1.php",    //the page containing php script
            type: "post",    //request type,
            dataType: 'json',
            data: {user_id: username, category: category, starttime: starttime, type: 'end'},
            success:function(result){
                console.log(result.abc);
            }
        });


}
</script>

    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Autosize Plugin Js -->
    <script src="plugins/autosize/autosize.js"></script>

    <!-- Moment Plugin Js -->
    <script src="plugins/momentjs/moment.js"></script>

    <!-- Bootstrap Material Datetime Picker Plugin Js -->
    <script src="plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

    <!-- Bootstrap Datepicker Plugin Js -->
    <script src="plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/forms/basic-form-elements.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>
</body>
</html>
